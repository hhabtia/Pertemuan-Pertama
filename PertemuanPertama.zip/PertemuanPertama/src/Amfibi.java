/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Amfibi extends Hewan {
    private String WarnaKulit;
    private String habitat;

    /**
     * @return the WarnaKulit
     */
    public String getWarnaKulit() {
        return WarnaKulit;
    }

    /**
     * @param WarnaKulit the WarnaKulit to set
     */
    public void setWarnaKulit(String WarnaKulit) {
        this.WarnaKulit = WarnaKulit;
    }

    /**
     * @return the habitat
     */
    public String getHabitat() {
        return habitat;
    }

    /**
     * @param habitat the habitat to set
     */
    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }
}
