/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Aves extends Hewan {
    private String WarnaBulu;
    private String BentukParuh;

    /**
     * @return the WarnaBulu
     */
    public String getWarnaBulu() {
        return WarnaBulu;
    }

    /**
     * @param WarnaBulu the WarnaBulu to set
     */
    public void setWarnaBulu(String WarnaBulu) {
        this.WarnaBulu = WarnaBulu;
    }

    /**
     * @return the BentukParuh
     */
    public String getBentukParuh() {
        return BentukParuh;
    }

    /**
     * @param BentukParuh the BentukParuh to set
     */
    public void setBentukParuh(String BentukParuh) {
        this.BentukParuh = BentukParuh;
    }
}
