/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Dikotil extends Tumbuhan {
    private String LajuPertumbuhan;
    private String BentukTulangDaun;

    /**
     * @return the LajuPertumbuhan
     */
    public String getLajuPertumbuhan() {
        return LajuPertumbuhan;
    }

    /**
     * @param LajuPertumbuhan the LajuPertumbuhan to set
     */
    public void setLajuPertumbuhan(String LajuPertumbuhan) {
        this.LajuPertumbuhan = LajuPertumbuhan;
    }

    /**
     * @return the BentukTulangDaun
     */
    public String getBentukTulangDaun() {
        return BentukTulangDaun;
    }

    /**
     * @param BentukTulangDaun the BentukTulangDaun to set
     */
    public void setBentukTulangDaun(String BentukTulangDaun) {
        this.BentukTulangDaun = BentukTulangDaun;
    }
}
