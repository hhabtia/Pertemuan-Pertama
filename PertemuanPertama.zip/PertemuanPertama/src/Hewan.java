/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Hewan extends MahlukhHidup {
    private int JumlahKaki;

    /**
     * @return the JumlahKaki
     */
    public int getJumlahKaki() {
        return JumlahKaki;
    }

    /**
     * @param JumlahKaki the JumlahKaki to set
     */
    public void setJumlahKaki(int JumlahKaki) {
        this.JumlahKaki = JumlahKaki;
    }
}
