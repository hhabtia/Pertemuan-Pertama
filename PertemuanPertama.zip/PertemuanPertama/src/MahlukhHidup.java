/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Habtia Humaira
 */
public class MahlukhHidup {
       public void bernafas() {  
        System.out.println("Saya bernafas");
    }
      public void tumbuh () {
          System.out.println("Saya tumbuh");
      }
      public void beradaptasi () {
          System.out.println("Saya beradaptasi");
      }
}
