/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Mamalia extends Hewan {
    private String BentukTubuh;
    private String AdaptasiFisik;

    /**
     * @return the BentukTubuh
     */
    public String getBentukTubuh() {
        return BentukTubuh;
    }

    /**
     * @param BentukTubuh the BentukTubuh to set
     */
    public void setBentukTubuh(String BentukTubuh) {
        this.BentukTubuh = BentukTubuh;
    }

    /**
     * @return the AdaptasiFisik
     */
    public String getAdaptasiFisik() {
        return AdaptasiFisik;
    }

    /**
     * @param AdaptasiFisik the AdaptasiFisik to set
     */
    public void setAdaptasiFisik(String AdaptasiFisik) {
        this.AdaptasiFisik = AdaptasiFisik;
    }
}
