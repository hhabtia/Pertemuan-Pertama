/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Monokotil extends Tumbuhan {
    private String BentukBatang;
    private String BentukDaun;

    /**
     * @return the BentukBatang
     */
    public String getBentukBatang() {
        return BentukBatang;
    }

    /**
     * @param BentukBatang the BentukBatang to set
     */
    public void setBentukBatang(String BentukBatang) {
        this.BentukBatang = BentukBatang;
    }

    /**
     * @return the BentukDaun
     */
    public String getBentukDaun() {
        return BentukDaun;
    }

    /**
     * @param BentukDaun the BentukDaun to set
     */
    public void setBentukDaun(String BentukDaun) {
        this.BentukDaun = BentukDaun;
    }
}
