/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Pisces extends Hewan {
    private String BentukTubuh;
    private String TingkahLaku;

    /**
     * @return the BentukTubuh
     */
    public String getBentukTubuh() {
        return BentukTubuh;
    }

    /**
     * @param BentukTubuh the BentukTubuh to set
     */
    public void setBentukTubuh(String BentukTubuh) {
        this.BentukTubuh = BentukTubuh;
    }

    /**
     * @return the TingkahLaku
     */
    public String getTingkahLaku() {
        return TingkahLaku;
    }

    /**
     * @param TingkahLaku the TingkahLaku to set
     */
    public void setTingkahLaku(String TingkahLaku) {
        this.TingkahLaku = TingkahLaku;
    }
}
