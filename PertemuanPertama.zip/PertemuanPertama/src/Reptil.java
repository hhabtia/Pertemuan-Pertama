/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Reptil extends Hewan {
    private String CaraReproduksi;
    private int JumlahKuku;

    /**
     * @return the CaraReproduksi
     */
    public String getCaraReproduksi() {
        return CaraReproduksi;
    }

    /**
     * @param CaraReproduksi the CaraReproduksi to set
     */
    public void setCaraReproduksi(String CaraReproduksi) {
        this.CaraReproduksi = CaraReproduksi;
    }

    /**
     * @return the JumlahKuku
     */
    public int getJumlahKuku() {
        return JumlahKuku;
    }

    /**
     * @param JumlahKuku the JumlahKuku to set
     */
    public void setJumlahKuku(int JumlahKuku) {
        this.JumlahKuku = JumlahKuku;
    }
}
