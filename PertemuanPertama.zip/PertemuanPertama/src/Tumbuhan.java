/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Habtia Humaira
 */
public class Tumbuhan extends MahlukhHidup {
    private String WarnaDaun;
    private String ArahDaun;

    /**
     * @return the WarnaDaun
     */
    public String getWarnaDaun() {
        return WarnaDaun;
    }

    /**
     * @param WarnaDaun the WarnaDaun to set
     */
    public void setWarnaDaun(String WarnaDaun) {
        this.WarnaDaun = WarnaDaun;
    }

    /**
     * @return the ArahDaun
     */
    public String getArahDaun() {
        return ArahDaun;
    }

    /**
     * @param ArahDaun the ArahDaun to set
     */
    public void setArahDaun(String ArahDaun) {
        this.ArahDaun = ArahDaun;
    }
}
